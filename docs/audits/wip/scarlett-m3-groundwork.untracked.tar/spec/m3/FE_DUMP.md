# M3-01: canonical frontend dumps and the M3 frontend lock

`omnic fe-dump` (workspace) and `omni_rust_bootstrap fe-dump` (monolith) record what the Rust frontend produces. The future Omni frontend in `pure/m3/` must reproduce it exactly.

```
fe-dump lock                                   # prints spec/m3/corpus.tsv
fe-dump tokens <file.omni> <out.bin> [--strict]
fe-dump stream <file.omni> <out.bin> [--strict]  # also writes <out.bin>.sm
```

Formats (all little-endian u16 words):
- **Token dump:** `[0x4D33, count_lo, count_hi]`, then per token `[kind, line_lo, line_hi, col_lo, col_hi, v0, v1, v2, v3, nbytes, bytes...]`.
  - `kind`: 1 Ident, 2 Int, 3 Trit, 4 StrLit, 5 AtIdent, 6 Sym, 7 Op, 8 Hash.
  - `v0..v3`: the i64 value (Int value or Trit value), else 0.
  - `bytes`: the token text as stored by the Rust lexer, one word per byte.
- **Stream:** the exact `compile_omni_surface_to_u16_with_sourcemap` output.
- **Sourcemap dump:** `[0x4D53, n_lo, n_hi]`, then per entry `[off, line, col]` as u32 pairs, then budget span, default span, and a pack5 flag + span.
- **Errors:** recorded as `CLASS:line:col`. Message text isn't locked.

`spec/m3/corpus.tsv` is the lock, one row per corpus entry, as `name, strict, tok=words:fnv1a64:tokv=words:fnv1a64 (same dump with all line/col zeroed), out=words:fnv1a64:sm=words:fnv1a64` (or `ERR:CLASS:line:col`). The monolith and workspace selftests (13AX), the workspace monolith-vs-workspace differential, and `cargo test` (`m3_fe_lock`) all assert it row for row.

Corpus:
- the 18 closed-suite modules from `lookup_omni_stdlib_module`, compiled strict as the suite does;
- `pure/verifier_engine.omni`;
- the 39 acceptance goldens on disk under `spec/acceptance/goldens/`;
- the 13 quirk fixtures in `spec/m3/fixtures/` (Q1-Q8 in `spec/m3/PLAN.md` §1).

`neg_circular_include.omni` is excluded because it reads a file relative to the process cwd, so its result depends on where you run it.

If an intentional frontend change alters a row, regenerate with `fe-dump lock > spec/m3/corpus.tsv` in the same commit, and justify the change in the commit message.

Observations recorded by the lock:
- `q8b_label_limit` (8 value `if_pos` = 16 labels) fails with `BUDGET_EXCEEDED:19:14`, while `q8c_label_ok` (14 labels) compiles. This confirms that 15 labels per function are usable today (open item O-1).
- `q6_include_twice` fails with `SYNTAX_ERROR:6:53`, because the textual include duplicates the function definitions.
- `q1_strict_substring` is rejected (`AMBIGUOUS_GRAMMAR`) only because the comment contains the strict marker.
